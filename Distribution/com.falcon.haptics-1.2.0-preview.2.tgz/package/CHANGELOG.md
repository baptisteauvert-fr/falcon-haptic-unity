# Changelog

## 1.2.0-preview.2

- Composant `FalconWorkspace` : origine physique, mapping vers le Transform de la scène, échelles par axe, inversion de Z et gizmos.
- Capture des extrema observés avec validation des trois axes et marge configurable ; recentrage sur lecture récente.
- Profils de calibration persistants, chargement et enregistrement explicites depuis l’inspecteur.
- Conversions indépendantes de Unity pour positions, vitesses et forces conjuguées, avec conservation du travail virtuel.
- Boîte logicielle facultative, limitation visuelle du curseur et désarmement dans le worker hors zone.
- Désarmement lors des changements de repère et pendant la capture ; préservation du mapping historique sans `FalconWorkspace`.

Les extrema ne certifient pas la géométrie accessible du Falcon. L’initialisation matérielle reste distincte de la calibration utilisateur. Les six effets existants restent calculés dans le repère matériel ; les conversions de forces sont proposées aux futurs effets et surfaces.

## 1.2.0-preview.1

- Extraction de `IFalconBackend` et de `FalconSession`, indépendants de Unity.
- Backend simulé avec position, boutons, déconnexion injectée et force enregistrée.
- État horodaté et séquencé, détection des lectures périmées et statistiques d’intervalles.
- Arrêt coopératif confirmé, contrôle du thread propriétaire DHD et connexion unique par processus.
- Nettoyage natif centralisé, erreurs remontées et DLL conservée si la fermeture échoue.
- Gestion des transitions Play, pauses et rechargements d’assemblies dans l’éditeur.
- Tests sans matériel et vérification reproductible des quatre configurations de Play Mode.

Les six effets et leurs plafonds sont conservés. Calibration, colliders, IL2CPP et validation matérielle de cette version restent à réaliser. Aucun mode 4/8 N ni rappel après relâchement n’est ajouté.
