using System;
using System.Diagnostics;

namespace Falcon.Haptics
{

internal sealed class EffectRequest
{
    public readonly HapticMode Mode;

    public EffectRequest(HapticMode mode)
    {
        Mode = mode;
    }
}

internal sealed class HapticPlayback : IDisposable
{
    readonly IFalconBackend falcon;
    EffectRequest selection;
    HapticEffect active;
    bool sawRelease;
    long lastUpdate;

    public HapticPlayback(IFalconBackend falcon)
    {
        this.falcon = falcon;
    }

    public bool Update(EffectRequest request, FalconSample sample, int intensity)
    {
        if (!ReferenceEquals(request, selection))
        {
            Stop();
            selection = request;
            sawRelease = false;
        }
        if (request == null)
            return false;

        if ((sample.Buttons & 1u) == 0)
        {
            Stop();
            sawRelease = true;
            return false;
        }
        if (!sawRelease)
            return false;

        long now = Stopwatch.GetTimestamp();
        if (active == null)
        {
            falcon.BeginHaptics(request.Mode);
            active = new HapticEffect(request.Mode, sample);
            lastUpdate = Stopwatch.GetTimestamp();
            return true;
        }

        float seconds = (float)((now - lastUpdate) / (double)Stopwatch.Frequency);
        lastUpdate = now;
        falcon.ApplyHaptics(active.Step(sample, seconds, intensity));
        return true;
    }

    public void Stop()
    {
        falcon.EndHaptics();
        active = null;
    }

    public void Dispose() => Stop();
}
}
