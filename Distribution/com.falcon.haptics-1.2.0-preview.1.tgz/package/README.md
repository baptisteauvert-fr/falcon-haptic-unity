﻿# Novint Falcon pour Unity

Le package `com.falcon.haptics` fournit une API C# pour les trois axes, les quatre boutons et les six modes haptiques du Novint Falcon. Le backend matériel nécessite Windows x64 et Force Dimension DHD x64. Un backend simulé permet de tester sans appareil ni SDK DHD. Sur le même PC, cliquer sur **Arrêter** dans Falcon Diagnostics pour libérer le périphérique avant d’entrer en Play Mode.

La version **1.2.0-preview.1** consolide les sessions et ajoute la simulation. Elle ne reprend pas les variantes expérimentales 4/8 N ou le rappel après relâchement de FalconLab. La calibration et les surfaces liées aux colliders seront ajoutées dans une étape suivante.

## Importer

1. Dans Unity, ouvrir **Window → Package Manager** et utiliser **+ → Install package from tarball**. Sélectionner `com.falcon.haptics-1.2.0-preview.1.tgz`. Pour développer depuis les sources, choisir **Install package from disk** et le fichier `package.json` de ce dossier.
2. Sur un GameObject, ajouter le composant **Input → Novint Falcon**. Ajouter facultativement un objet distinct dans **Cursor**.
3. Pour une interface de test, importer **Falcon Monitor** depuis l’onglet **Samples** du package. Ajouter le composant **Falcon Monitor** à un GameObject, lancer Play, puis cliquer dans la vue **Game**. Le composant ajoute automatiquement `FalconInput` s’il manque.

## API

- `FalconInput.Connected`, `PositionMetres`, `Buttons`, `IsButtonPressed(0…3)` et `Status` donnent l’état de lecture.
- `TryArmEffect(HapticMode.Water, 30)` prépare un effet à 30 %. L’utilisateur doit relâcher puis maintenir le bouton 1 de la poignée pour recevoir l’effort. La méthode retourne `false` sans connexion ou sans focus.
- `EffectArmed`, `EffectActive` et `EffectError` permettent de présenter l’état ou le dernier problème. `SetEffectIntensity(0…100)` modifie le gain et `DisarmEffect()` arrête l’effet.
- Modes disponibles dans `HapticMode` · `Water`, `Brick`, `Resistance`, `Spring`, `Gravel`, `EngineLever`.
- `PositionMetres` est exprimée dans le repère brut du Falcon. Le curseur facultatif inverse l’axe Z pour l’affichage et applique **Unity Units Per Metre**.
- `ConnectionState`, `SampleSequence` et `SampleAgeSeconds` distinguent l’état de session et la fraîcheur de la dernière lecture. Au-delà de 100 ms, la lecture devient périmée et `Connected` est faux. Cet âge mesure la réception côté logiciel, pas l’âge d’une mesure interne au contrôleur.
- `MeanIntervalMilliseconds` et `MaximumIntervalMilliseconds` mesurent les intervalles entre lectures réussies sur la session. Ces statistiques incluent les attentes volontaires de 8 ms au repos et 2 ms lorsqu’un effet est armé ; elles ne constituent pas une validation à 1 kHz.

## Essayer sans Falcon

1. Ajouter **Input → Novint Falcon** et sélectionner **Backend → Simulation** avant Play.
2. Lancer Play. Modifier **Simulation Position Metres** et le masque **Simulation Buttons** dans l’inspecteur.
3. Pour essayer le ressort dans le moniteur : laisser les boutons à zéro, activer le ressort, puis passer le masque à `1` et déplacer la position simulée. Garder la vue Game au premier plan pour l’armement et le signal de vie.
4. Lire **SimulatedForceNewtons** par l’API ou dans le moniteur ; cette force est enregistrée, jamais appliquée à un moteur. Remettre le masque à zéro arrête l’effort.
5. Décocher **Simulation Available** injecte une déconnexion. La reconnexion revient sans effet armé.

`SetSimulationSample(Vector3 positionMetres, uint buttons)` et `SetSimulationAvailable(bool)` permettent de piloter ces entrées depuis un script Unity sur le thread principal. Le bit 0 du masque correspond au bouton 1, le bit 3 au bouton 4. Le simulateur ne modélise pas la mécanique du Falcon ni la réaction de l’utilisateur.

## Sessions et arrêt

`IFalconBackend` sépare le transport et le calcul d’effets. `FalconSession` possède son backend sur un thread dédié ; la factory fournie à son constructeur y est exécutée. Elle ne doit pas accéder à des objets Unity. `SimulatedFalconBackend.SetSample`, `SetAvailable` et `CommandedForce` sont synchronisés pour les échanges avec le thread appelant.

`FalconSession.State` renvoie une copie cohérente, sans allocation de snapshot par lecture. Les six effets et leurs plafonds actuels (1,2 ou 1,8 N) restent identiques. Une absence de signal de vie pendant 240 ms désarme l’effet ; une lecture ou un intervalle supérieur à 45 ms pendant l’armement provoque une erreur et un désarmement. Ces seuils logiciels ne sont pas des limites matérielles certifiées.

`RequestStop()` demande l’arrêt. `Stop(timeoutMilliseconds)` retourne `true` uniquement après terminaison du worker. Il faut aussi examiner `State.EffectError` : un thread terminé ne prouve pas à lui seul la réussite de la coupure matérielle. `Dispose()` lève une exception si le worker ne s’arrête pas dans le délai. En cas de délai dépassé, la session garde le backend ; aucun autre thread ne le ferme ou ne décharge sa DLL.

Le backend DHD refuse une deuxième connexion dans le même processus. Ses opérations doivent rester sur le thread où il a été construit. La fermeture tente zéro, désactivation, fermeture et déchargement, en remontant les erreurs. Si la fermeture native échoue, le handle et la DLL restent réservés et la reconnexion automatique est interrompue ; une intervention et éventuellement un redémarrage du processus sont nécessaires.

L’intégration éditeur demande l’arrêt avant rechargement d’assemblies, sortie de Play et fermeture ; elle désarme lors d’une pause de l’éditeur. Elle relance les composants actifs à l’entrée en Play, y compris sans rechargement du domaine ou de la scène.

**Limite importante :** si un appel DHD se bloque, le code peut constater une lecture périmée et un arrêt non confirmé, mais ne peut pas imposer une force nulle à travers cet appel. Le comportement du pilote, du firmware et d’un éventuel watchdog doit être mesuré sur un Falcon réel. Le simulateur ne valide pas cette protection.

## Compatibilité

Le minimum déclaré reste Unity 2021.3 et les API .NET Standard 2.1 ; ce minimum n’est pas encore validé dans un éditeur 2021.3. Le backend matériel cible un éditeur ou Player Windows x64. Le SDK officiel et le pilote restent installés sur le PC. Le package contient les sources C# et utilise `dhd64.dll` à partir de l’installation officielle. Le champ **Dhd Library Path** accepte son chemin absolu si nécessaire. [Téléchargement du SDK Force Dimension](https://forcedimension.com/software)

Les validations matérielles historiques de 1.1.0 ne qualifient pas automatiquement cette préversion. IL2CPP, les autres systèmes, les forces et les scénarios d’incident réels restent à valider. Les tests reproductibles sont décrits dans `Tests/README.md` à la racine du dépôt.

