# Changelog

## 1.2.0-preview.1

- Extraction de `IFalconBackend` et de `FalconSession`, indépendants de Unity.
- Backend simulé avec position, boutons, déconnexion injectée et force enregistrée.
- État horodaté et séquencé, détection des lectures périmées et statistiques d’intervalles.
- Arrêt coopératif confirmé, contrôle du thread propriétaire DHD et connexion unique par processus.
- Nettoyage natif centralisé, erreurs remontées et DLL conservée si la fermeture échoue.
- Gestion des transitions Play, pauses et rechargements d’assemblies dans l’éditeur.
- Tests sans matériel et vérification reproductible des quatre configurations de Play Mode.

Les six effets et leurs plafonds sont conservés. Calibration, colliders, IL2CPP et validation matérielle de cette version restent à réaliser. Aucun mode 4/8 N ni rappel après relâchement n’est ajouté.
