using System;
using System.Diagnostics;
using System.Threading;
using UnityEngine;

namespace Falcon.Haptics
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Input/Novint Falcon")]
    public sealed class FalconInput : MonoBehaviour
    {
        [SerializeField, Tooltip("Chemin absolu vers dhd64.dll. Vide = détection du SDK installé.")]
        string dhdLibraryPath;
        [SerializeField, Tooltip("Objet facultatif à déplacer dans le repère local Unity.")]
        Transform cursor;
        [SerializeField, Min(0)]
        float unityUnitsPerMetre = 10;

        Reader reader;
        bool paused;
        public bool Connected { get; private set; }
        public Vector3 PositionMetres { get; private set; }
        public uint Buttons { get; private set; }
        public string Status { get; private set; } = "Arrêté";
        public bool EffectArmed => reader?.EffectArmed == true;
        public bool EffectActive => reader?.EffectActive == true;
        public string EffectError => reader?.EffectError ?? string.Empty;

        public bool IsButtonPressed(int index) =>
            Connected && index >= 0 && index < 4 && (Buttons & (1u << index)) != 0;

        public bool TryArmEffect(HapticMode mode, int intensity = 30)
        {
            if (!isActiveAndEnabled || !Connected || paused || !Application.isFocused ||
                reader == null || reader.Stopping || !Enum.IsDefined(typeof(HapticMode), mode))
                return false;

            reader.Arm(mode, intensity);
            return true;
        }

        public void SetEffectIntensity(int intensity) => reader?.SetIntensity(intensity);
        public void DisarmEffect() => reader?.Disarm();

        void OnApplicationFocus(bool focused)
        {
            if (!focused)
                DisarmEffect();
        }

        void OnApplicationPause(bool pause)
        {
            paused = pause;
            if (pause)
                DisarmEffect();
        }

        void OnEnable()
        {
#if UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN
            if (!string.IsNullOrWhiteSpace(dhdLibraryPath) && !FalconSdk.IsLibrary(dhdLibraryPath))
            {
                Status = "Le chemin configuré doit pointer vers dhd64.dll.";
                return;
            }
            if (reader != null && reader.IsRunning)
                return;
            reader = new Reader(string.IsNullOrWhiteSpace(dhdLibraryPath) ? null : dhdLibraryPath);
#else
            Status = "Le Falcon requiert Windows x64.";
#endif
        }

        void Update()
        {
            if (reader == null)
                return;
            if (reader.Stopping)
            {
                if (!reader.IsRunning)
                {
                    reader = null;
                    OnEnable();
                }
                return;
            }
            if (!paused && Application.isFocused)
                reader.UpdateHeartbeat();
            else
                reader.Disarm();

            var state = reader.State;
            Status = state.Message;
            Connected = state.Sample.HasValue;
            Buttons = state.Sample?.Buttons ?? 0;
            if (state.Sample is FalconSample sample)
            {
                PositionMetres = new Vector3((float)sample.X, (float)sample.Y, (float)sample.Z);
                if (cursor != null)
                    cursor.localPosition = new Vector3(PositionMetres.x, PositionMetres.y, -PositionMetres.z) * unityUnitsPerMetre;
            }
            else
            {
                PositionMetres = Vector3.zero;
            }
        }

        void OnDisable()
        {
            reader?.Stop();
            Connected = false;
            PositionMetres = Vector3.zero;
            Buttons = 0;
            Status = "Arrêté";
        }

        sealed class Reader
        {
            readonly string path;
            readonly Thread thread;
            int stopping;
            int intensity = 30, effectActive;
            long heartbeat;
            string effectError;
            EffectRequest effectRequest;
            Snapshot state = new Snapshot(null, "Recherche du Falcon…");

            public Snapshot State => Volatile.Read(ref state);
            public bool IsRunning => thread.IsAlive;
            public bool Stopping => Volatile.Read(ref stopping) != 0;
            public bool EffectArmed => Volatile.Read(ref effectRequest) != null;
            public bool EffectActive => Volatile.Read(ref effectActive) != 0;
            public string EffectError => Volatile.Read(ref effectError);

            public Reader(string path)
            {
                this.path = path;
                thread = new Thread(Loop) { IsBackground = true, Name = "Novint Falcon" };
                thread.Start();
            }

            public void Stop()
            {
                Disarm();
                Volatile.Write(ref stopping, 1);
                thread.Join(100);
            }

            public void Arm(HapticMode mode, int gain)
            {
                SetIntensity(gain);
                Volatile.Write(ref effectError, null);
                UpdateHeartbeat();
                Volatile.Write(ref effectRequest, new EffectRequest(mode));
            }

            public void SetIntensity(int gain) => Volatile.Write(ref intensity, Math.Clamp(gain, 0, 100));
            public void UpdateHeartbeat() => Interlocked.Exchange(ref heartbeat, Stopwatch.GetTimestamp());
            public void Disarm() => Volatile.Write(ref effectRequest, null);

            void Loop()
            {
                while (!Stopping)
                {
                    try
                    {
                        string library = path ?? FalconSdk.Find();
                        if (library == null)
                            throw new InvalidOperationException("Installez Force Dimension DHD x64.");
                        using (var device = new FalconDevice(library))
                        {
                            device.Connect();
                            string version = device.SdkVersion;
                            using var playback = new HapticPlayback(device);
                            while (!Stopping)
                            {
                                FalconSample sample = device.Read();
                                Volatile.Write(ref state, new Snapshot(sample, version));
                                if (Stopping)
                                    break;
                                Thread.Sleep(UpdateEffect(playback, sample) ? 2 : 8);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Disarm();
                        Volatile.Write(ref effectActive, 0);
                        Volatile.Write(ref state, new Snapshot(null, ex.Message));
                        for (int elapsed = 0; elapsed < 750 && !Stopping; elapsed += 30)
                            Thread.Sleep(30);
                    }
                }
                Volatile.Write(ref effectActive, 0);
            }

            bool UpdateEffect(HapticPlayback playback, FalconSample sample)
            {
                EffectRequest request = Volatile.Read(ref effectRequest);
                if (request != null && Stopwatch.GetTimestamp() - Interlocked.Read(ref heartbeat) > Stopwatch.Frequency * .24)
                {
                    Interlocked.CompareExchange(ref effectRequest, null, request);
                    request = null;
                }

                try
                {
                    bool active = playback.Update(request, sample, Volatile.Read(ref intensity));
                    Volatile.Write(ref effectActive, active ? 1 : 0);
                }
                catch (Exception ex)
                {
                    Interlocked.CompareExchange(ref effectRequest, null, request);
                    Volatile.Write(ref effectError, ex.Message);
                    playback.Stop();
                    Volatile.Write(ref effectActive, 0);
                }
                return request != null;
            }
        }

        sealed class Snapshot
        {
            public readonly FalconSample? Sample;
            public readonly string Message;

            public Snapshot(FalconSample? sample, string message)
            {
                Sample = sample;
                Message = message;
            }
        }
    }
}
