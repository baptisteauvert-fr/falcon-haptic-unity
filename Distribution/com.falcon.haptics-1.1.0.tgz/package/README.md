﻿# Novint Falcon pour Unity

Le package `com.falcon.haptics` fournit une API C# pour les trois axes, les quatre boutons et les six modes haptiques du Novint Falcon. Windows x64 et Force Dimension DHD x64 sont requis. Sur le même PC, cliquer sur **Arrêter** dans Falcon Diagnostics pour libérer le périphérique avant d’entrer en Play Mode.

## Importer

1. Dans Unity, ouvrir **Window → Package Manager** et utiliser **+ → Install package from tarball**. Sélectionner `com.falcon.haptics-1.1.0.tgz`.
2. Sur un GameObject, ajouter le composant **Input → Novint Falcon**. Ajouter facultativement un objet distinct dans **Cursor**.
3. Pour une interface de test, importer **Falcon Monitor** depuis l’onglet **Samples** du package. Ajouter le composant **Falcon Monitor** à un GameObject, lancer Play, puis cliquer dans la vue **Game**. Le composant ajoute automatiquement `FalconInput` s’il manque.

## API

- `FalconInput.Connected`, `PositionMetres`, `Buttons`, `IsButtonPressed(0…3)` et `Status` donnent l’état de lecture.
- `TryArmEffect(HapticMode.Water, 30)` prépare un effet à 30 %. L’utilisateur doit relâcher puis maintenir le bouton 1 de la poignée pour recevoir l’effort. La méthode retourne `false` sans connexion ou sans focus.
- `EffectArmed`, `EffectActive` et `EffectError` permettent de présenter l’état ou le dernier problème. `SetEffectIntensity(0…100)` modifie le gain et `DisarmEffect()` arrête l’effet.
- Modes disponibles dans `HapticMode` · `Water`, `Brick`, `Resistance`, `Spring`, `Gravel`, `EngineLever`.
- `PositionMetres` est exprimée dans le repère brut du Falcon. Le curseur facultatif inverse l’axe Z pour l’affichage et applique **Unity Units Per Metre**.

## Compatibilité

Le package cible les API .NET Standard 2.1 avec Unity 2021.3 ou ultérieur, sur un éditeur ou Player Windows x64. Le SDK officiel et le pilote restent installés sur le PC. Le package contient les sources C# et utilise `dhd64.dll` à partir de l’installation officielle. Le champ **Dhd Library Path** accepte son chemin absolu si nécessaire. [Téléchargement du SDK Force Dimension](https://forcedimension.com/software)

