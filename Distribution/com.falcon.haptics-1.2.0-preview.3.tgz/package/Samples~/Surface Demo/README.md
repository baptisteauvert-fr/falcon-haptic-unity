# Première surface en simulation

Importer **Surface Demo** depuis les Samples du package, puis ouvrir `FalconSurfaceDemo.unity` et lancer Play. Cette scène sélectionne le backend Simulation ; elle ne charge pas le Falcon.

1. Laisser le bouton simulé relâché et le curseur à Z = +6 mm.
2. Dans la vue Game, cliquer sur **Activer la surface à 30 %**.
3. Cocher **Maintenir le bouton 1 simulé**, puis réduire Z vers +2 mm et au-delà. La force commence lorsque la sphère de rayon 2 mm rencontre la face, située à Z brut = 0.
4. Déplacer X ou Y pour observer l’atténuation près du bord puis l’absence de force hors de la face. Le relâchement du bouton arrête l’effort.
5. **Replacer devant la face** coupe les forces et remet la position de départ.

Le champ **Force calculée** affiche la commande simulée en newtons matériels. Le curseur montre la position mesurée et peut pénétrer la paroi : ce prototype utilise une surface souple, sans proxy géométrique contraint. Les réglages par défaut du composant limitent la force à 0,6 N à 100 %, donc 0,18 N à 30 %. Ce sont des choix logiciels de démonstration, pas des limites matérielles qualifiées.

Une seule face du cube est haptique : **Negative Z** dans la scène, orientée vers Z positif dans le repère brut du Falcon après inversion du mapping. Les autres faces et les arêtes ne produisent pas de contact. Aucun effet de friction n’est ajouté à cette version.

La scène démarre devant la face. Activer le bouton alors que l’outil est déjà derrière celle-ci provoque un refus et un désarmement. Pour reprendre, relâcher le bouton, replacer l’outil devant et activer à nouveau.

Les modifications de géométrie, du mapping et des paramètres désarment l’interaction. Les Rigidbody, même cinématiques, sont refusés. L’absence de publication de la géométrie pendant 100 ms désarme aussi la surface. La stabilité, les axes et la coupure réelles nécessitent une validation séparée sur un Falcon.
